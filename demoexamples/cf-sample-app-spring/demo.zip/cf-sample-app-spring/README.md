# Spring Sample App

```cf push```

https://docs.cloudfoundry.org/buildpacks/java/java-tips.html
